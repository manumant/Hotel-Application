﻿using SPMS.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SPMS.Controllers
{
     [Authorize]
    public class ParentController : Controller
    {
        public UsersContext db = new UsersContext();
        //
        // GET: /Parent/

        public ActionResult Index()
        {
            return View(db.parent.ToList());
        }

        //
        // GET: /Parent/Details/5

        public ActionResult Details(int id)
        {
            Parent obj = db.parent.Find(id);
            return View(obj);
        }

        //
        // GET: /Parent/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /Parent/Create

        [HttpPost]
        public ActionResult Create(Parent model)
        {
            try
            {
                // TODO: Add insert logic here
                db.Entry(model).State = EntityState.Added;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Parent/Edit/5

        public ActionResult Edit(int id)
        {
            Parent obj1 = db.parent.Find(id);
            return View(obj1);
        }

        //
        // POST: /Parent/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, Parent model)
        {
            try
            {
                // TODO: Add update logic here
                db.Entry(model).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /Parent/Delete/5

        public ActionResult Delete(int id)
        {
            Parent obj2 = db.parent.Find(id);

            return View(obj2);
        }

        //
        // POST: /Parent/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, Parent model)
        {
            try
            {
                // TODO: Add delete logic here
                Parent obj2 =  db.parent.Find(id);
                db.parent.Remove(obj2);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
